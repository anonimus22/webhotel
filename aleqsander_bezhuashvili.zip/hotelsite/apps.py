from django.apps import AppConfig


class HotelsiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hotelsite'
